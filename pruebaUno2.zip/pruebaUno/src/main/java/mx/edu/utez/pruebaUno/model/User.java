package mx.edu.utez.pruebaUno.model;


import jakarta.persistence.*;
import lombok.*;

import java.time.LocalDate;
import java.util.Random;


@Entity
@Table(name = "users")
@Setter
@Getter
@NoArgsConstructor
@AllArgsConstructor
public class User {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    @Column(length = 40, nullable = false)
    private String username;
    private String password;
    private Boolean status;

    public User(String username,  Boolean status) {
        this.username = username;
        this.password = createPassword();
        this.status = status;
    }

    private String createPassword() {
        String numerosLetrasAleatorias = "ABS#CEF$GHIJK%LMNO&PQRSTUV#WXYZ&1$23456789$ab%&cde#fghijklmn&opqrstuvwxyz";
        String password = "";

        for (int i = 0; i < 8; i++) {
            int randomIndex = (int) (Math.random() * numerosLetrasAleatorias.length());
            password += numerosLetrasAleatorias.charAt(randomIndex);
        }

        return password;
    }

}
