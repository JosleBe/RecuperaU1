package mx.edu.utez.pruebaUno.services;

import mx.edu.utez.pruebaUno.config.ApiResponse;
import mx.edu.utez.pruebaUno.model.User;
import mx.edu.utez.pruebaUno.model.UserRepository;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.Optional;

@Service
@Transactional
public class UserService {
    private final UserRepository userRepository;

    public UserService(UserRepository bookRepository) {
        this.userRepository = bookRepository;
    }

    public ResponseEntity<ApiResponse> save(User user) {
        Optional<User> foundUserByPassword = userRepository.getUsersByPassword(user.getPassword());
        Optional<User> founUserByUsername = userRepository.getUsersByUsername(user.getUsername());
        if (foundUserByPassword.isPresent() || founUserByUsername.isPresent()) {
            return new ResponseEntity<>(new ApiResponse(HttpStatus.BAD_REQUEST, true, "AlreadyExist"), HttpStatus.BAD_REQUEST);
        }
        userRepository.save(user);
        return new ResponseEntity<>(new ApiResponse(HttpStatus.OK, false, "UserCretated"), HttpStatus.OK);
    }

    public ResponseEntity<ApiResponse> update(User user) {
        Optional<User> founUserByUsername = userRepository.getUsersByUsername(user.getUsername());
        if (founUserByUsername.isPresent()){
            return new ResponseEntity<>(new ApiResponse(HttpStatus.BAD_REQUEST, true, "AlreadyExist"), HttpStatus.BAD_REQUEST);
        }
        userRepository.save(user);
        return new ResponseEntity<>(new ApiResponse(HttpStatus.OK, false, "UserCretated"), HttpStatus.OK);
    }

    public List<User> getAllUser() {
        return userRepository.findAll();
    }

    @Transactional(readOnly = true)
    public Optional getOneUser(Long id) {
        return userRepository.getUserById(id);

    }

    public ResponseEntity<ApiResponse> deleteUser(Long id) {
        Optional user = userRepository.getUserById(id);
        if (user.isPresent()) {
            userRepository.deleteById(id);
            return new ResponseEntity<>(new ApiResponse(HttpStatus.OK, false, "usuarioBorrado"), HttpStatus.OK);
        }
        return new ResponseEntity<>(new ApiResponse(HttpStatus.BAD_REQUEST, true, "UsuarioNotFound"), HttpStatus.BAD_REQUEST);
    }
}
