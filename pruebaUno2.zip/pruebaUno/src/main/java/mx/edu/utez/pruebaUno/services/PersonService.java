package mx.edu.utez.pruebaUno.services;

import mx.edu.utez.pruebaUno.config.ApiResponse;
import mx.edu.utez.pruebaUno.model.Person;
import mx.edu.utez.pruebaUno.model.PersonRepository;
import mx.edu.utez.pruebaUno.model.User;
import mx.edu.utez.pruebaUno.model.UserRepository;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.Optional;

@Service
@Transactional
public class PersonService {
    private final PersonRepository personRepository;

    public PersonService(PersonRepository personRepository) {
        this.personRepository = personRepository;
    }

    public ResponseEntity<ApiResponse> save(Person user) {

        personRepository.save(user);
        return new ResponseEntity<>(new ApiResponse(HttpStatus.OK, false, "UserCretated"), HttpStatus.OK);
    }

    public ResponseEntity<ApiResponse> update(Person user) {

        personRepository.save(user);
        return new ResponseEntity<>(new ApiResponse(HttpStatus.OK, false, "UserCretated"), HttpStatus.OK);
    }

    public List<Person> getAllUser() {
        return personRepository.findAll();
    }

    @Transactional(readOnly = true)
    public Optional getOneUser(Long id) {
        return personRepository.findPersonById(id);

    }

    public ResponseEntity<ApiResponse> deleteUser(Long id) {
        Optional user = personRepository.findPersonById(id);
        if (user.isPresent()) {
            personRepository.deleteById(id);
            return new ResponseEntity<>(new ApiResponse(HttpStatus.OK, false, "usuarioBorrado"), HttpStatus.OK);
        }
        return new ResponseEntity<>(new ApiResponse(HttpStatus.BAD_REQUEST, true, "UsuarioNotFound"), HttpStatus.BAD_REQUEST);
    }
}
