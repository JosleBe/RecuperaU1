package mx.edu.utez.pruebaUno;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PruebaUnoApplication {

	public static void main(String[] args) {
		SpringApplication.run(PruebaUnoApplication.class, args);
	}

}
