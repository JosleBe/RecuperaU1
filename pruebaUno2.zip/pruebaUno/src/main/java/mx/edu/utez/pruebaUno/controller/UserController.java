package mx.edu.utez.pruebaUno.controller;

import mx.edu.utez.pruebaUno.config.ApiResponse;
import mx.edu.utez.pruebaUno.controller.dto.UserDto;
import mx.edu.utez.pruebaUno.model.User;
import mx.edu.utez.pruebaUno.services.UserService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("api/user")
public class UserController {
    private final UserService userService;

    public UserController(UserService userService) {
        this.userService = userService;
    }


    @PostMapping("/")
    public ResponseEntity<ApiResponse> save(@RequestBody UserDto user) {
     return  userService.save(user.toEntity());
    }

    @GetMapping("/")
    public List<User> getAll() {
         return  userService.getAllUser();

    }

    @GetMapping("/{id}")
    public Optional getOne(@PathVariable("id") Long id) {
        return  userService.getOneUser(id);

    }

    @PutMapping("/")
    public ResponseEntity<ApiResponse> update(@RequestBody UserDto user) {
        return userService.update(user.toEntity());
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<ApiResponse> delete(@PathVariable("id") Long id) {
      return   userService.deleteUser(id);

    }

}
