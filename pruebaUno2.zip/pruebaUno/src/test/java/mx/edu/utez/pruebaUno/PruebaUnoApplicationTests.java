package mx.edu.utez.pruebaUno;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PruebaUnoApplicationTests {

	@Test
	void contextLoads() {
	}

}
